// ============================================================================
//  approve.ts
// ----------------------------------------------------------------------------
//  Ensure the TokenMessengerV2 contract has at least `amount` USDC allowance
//  on Base. Sends an approve() tx only if necessary.
// ============================================================================

import type { Account, PublicClient, WalletClient } from "viem";
import { ERC20_ABI, TOKEN_MESSENGER_V2, USDC_BASE } from "./constants.js";
import { log } from "./logger.js";
import { formatUsdc } from "./utils.js";

export async function ensureApproval(params: {
  publicClient: PublicClient;
  walletClient: WalletClient;
  account: Account;
  amount: bigint;
}): Promise<void> {
  const { publicClient, walletClient, account, amount } = params;

  log.step("Checking USDC allowance on Base");
  const current = (await publicClient.readContract({
    address: USDC_BASE,
    abi: ERC20_ABI,
    functionName: "allowance",
    args: [account.address, TOKEN_MESSENGER_V2],
  })) as bigint;

  log.key("Current allowance:", `${formatUsdc(current)} USDC`);
  log.key("Required:         ", `${formatUsdc(amount)} USDC`);

  if (current >= amount) {
    log.ok("Sufficient allowance already granted. Skipping approve().");
    return;
  }

  log.step("Sending approve() on Base");
  const hash = await walletClient.writeContract({
    account,
    chain: null,
    address: USDC_BASE,
    abi: ERC20_ABI,
    functionName: "approve",
    args: [TOKEN_MESSENGER_V2, amount],
  });
  log.key("approve tx hash:", hash);

  log.wait("Waiting for approve() confirmation…");
  const receipt = await publicClient.waitForTransactionReceipt({ hash });
  if (receipt.status !== "success") {
    throw new Error(`approve() reverted. tx: ${hash}`);
  }
  log.ok(`approve() confirmed in block ${receipt.blockNumber}`);
}
