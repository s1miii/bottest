// ============================================================================
//  logger.ts
// ----------------------------------------------------------------------------
//  Colorful CLI logger built on chalk.
// ============================================================================

import chalk from "chalk";

const ts = () => chalk.gray(`[${new Date().toISOString().slice(11, 19)}]`);

export const log = {
  info: (msg: string) => console.log(`${ts()} ${chalk.cyan("ℹ")}  ${msg}`),
  step: (msg: string) => console.log(`${ts()} ${chalk.magenta("▶")}  ${chalk.bold(msg)}`),
  ok: (msg: string) => console.log(`${ts()} ${chalk.green("✔")}  ${msg}`),
  warn: (msg: string) => console.log(`${ts()} ${chalk.yellow("⚠")}  ${msg}`),
  err: (msg: string) => console.log(`${ts()} ${chalk.red("✖")}  ${msg}`),
  wait: (msg: string) => console.log(`${ts()} ${chalk.blue("…")}  ${msg}`),
  key: (label: string, value: string) =>
    console.log(`${ts()} ${chalk.gray("·")}  ${chalk.bold(label)} ${chalk.white(value)}`),
  banner: (msg: string) => {
    const line = "─".repeat(Math.max(msg.length + 4, 40));
    console.log("\n" + chalk.cyan(line));
    console.log(chalk.cyan("  ") + chalk.bold.white(msg));
    console.log(chalk.cyan(line) + "\n");
  },
  done: (msg: string) => {
    const line = "═".repeat(Math.max(msg.length + 4, 40));
    console.log("\n" + chalk.green(line));
    console.log(chalk.green("  ") + chalk.bold.greenBright(msg));
    console.log(chalk.green(line) + "\n");
  },
};
