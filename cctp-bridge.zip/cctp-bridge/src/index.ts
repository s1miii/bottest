// ============================================================================
//  index.ts — CLI entry point
// ============================================================================

import { runBridge } from "./bridge.js";
import { log } from "./logger.js";

runBridge().catch((err: unknown) => {
  const message = err instanceof Error ? err.message : String(err);
  log.err(message);
  if (err instanceof Error && err.stack) {
    console.error(err.stack);
  }
  process.exit(1);
});
