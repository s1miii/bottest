// ============================================================================
//  iris.ts
// ----------------------------------------------------------------------------
//  Circle Iris V2 attestation client.
//  Docs: https://developers.circle.com/cctp/technical-guide
//  Endpoint: GET {IRIS_API}/v2/messages/{sourceDomain}?transactionHash={txHash}
// ============================================================================

import type { Hex } from "viem";
import { IRIS_API, POLL_INTERVAL_MS, ATTESTATION_TIMEOUT_MS } from "./config.js";
import { log } from "./logger.js";
import { sleep, validateHex } from "./utils.js";

interface IrisMessage {
  message?: string;
  attestation?: string;
  status?: string;
  eventNonce?: string;
  cctpVersion?: number;
  delayReason?: string | null;
}

interface IrisResponse {
  messages?: IrisMessage[];
  error?: string;
}

export interface Attestation {
  message: Hex;
  attestation: Hex;
  eventNonce?: string;
}

/**
 * Poll Circle's Iris V2 API every POLL_INTERVAL_MS until a message is
 * available with status === "complete", then return the raw message
 * bytes + attestation signature ready for MessageTransmitterV2.receiveMessage.
 */
export async function waitForAttestation(params: {
  sourceDomain: number;
  burnTxHash: Hex;
}): Promise<Attestation> {
  const { sourceDomain, burnTxHash } = params;
  const url = `${IRIS_API.replace(/\/+$/, "")}/v2/messages/${sourceDomain}?transactionHash=${burnTxHash}`;

  log.step("Waiting for Circle attestation");
  log.key("Iris endpoint:", url);

  const started = Date.now();
  let lastStatus: string | undefined;
  let attempt = 0;

  while (true) {
    attempt += 1;
    if (Date.now() - started > ATTESTATION_TIMEOUT_MS) {
      throw new Error(
        `Timed out waiting for attestation after ${Math.round(
          ATTESTATION_TIMEOUT_MS / 1000
        )}s. Burn tx: ${burnTxHash}`
      );
    }

    let res: Response;
    try {
      res = await fetch(url, { headers: { accept: "application/json" } });
    } catch (e) {
      log.warn(`Iris fetch failed (attempt ${attempt}): ${(e as Error).message}`);
      await sleep(POLL_INTERVAL_MS);
      continue;
    }

    // 404 means "not yet observed"
    if (res.status === 404) {
      if (lastStatus !== "not_found") {
        log.wait("Message not yet observed by Iris… polling every 5s");
        lastStatus = "not_found";
      }
      await sleep(POLL_INTERVAL_MS);
      continue;
    }

    if (!res.ok) {
      log.warn(`Iris returned HTTP ${res.status}. Retrying…`);
      await sleep(POLL_INTERVAL_MS);
      continue;
    }

    const body = (await res.json()) as IrisResponse;
    const msg = body.messages?.[0];

    if (!msg || !msg.status) {
      if (lastStatus !== "empty") {
        log.wait("Iris response empty. Waiting for indexing…");
        lastStatus = "empty";
      }
      await sleep(POLL_INTERVAL_MS);
      continue;
    }

    if (msg.status !== lastStatus) {
      log.info(`Iris status: ${msg.status}${msg.delayReason ? ` (${msg.delayReason})` : ""}`);
      lastStatus = msg.status;
    }

    if (msg.status === "complete" && msg.message && msg.attestation) {
      log.ok("Attestation received ✔");
      return {
        message: validateHex(msg.message, "iris.message"),
        attestation: validateHex(msg.attestation, "iris.attestation"),
        eventNonce: msg.eventNonce,
      };
    }

    await sleep(POLL_INTERVAL_MS);
  }
}
