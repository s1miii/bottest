// ============================================================================
//  bridge.ts
// ----------------------------------------------------------------------------
//  Orchestrates the full Base → Arc CCTP V2 bridge:
//    1. Validate config
//    2. Connect Base + Arc RPCs
//    3. Check USDC + native gas balances
//    4. Approve TokenMessengerV2 if needed
//    5. depositForBurn on Base
//    6. Poll Iris for attestation
//    7. receiveMessage on Arc
// ============================================================================

import {
  createPublicClient,
  createWalletClient,
  http,
  type Address,
  type Hex,
} from "viem";
import { privateKeyToAccount } from "viem/accounts";

import {
  AMOUNT_USDC,
  ARC_RPC,
  BASE_RPC,
  IRIS_API,
  MAX_FEE_USDC,
  PRIVATE_KEY,
  RECIPIENT_OVERRIDE,
  TRANSFER_MODE,
} from "./config.js";
import {
  DOMAIN_ARC,
  DOMAIN_BASE,
  ERC20_ABI,
  FINALITY_THRESHOLD_FAST,
  FINALITY_THRESHOLD_STANDARD,
  TOKEN_MESSENGER_V2,
  TOKEN_MESSENGER_V2_ABI,
  USDC_ARC,
  USDC_BASE,
} from "./constants.js";
import { ensureApproval } from "./approve.js";
import { waitForAttestation } from "./iris.js";
import { receiveOnArc } from "./mint.js";
import { log } from "./logger.js";
import {
  addressToBytes32,
  formatUsdc,
  parseUsdc,
  sleep,
  validateAddress,
  validatePrivateKey,
  validateRpc,
} from "./utils.js";

const ZERO_BYTES32: Hex =
  "0x0000000000000000000000000000000000000000000000000000000000000000";

export async function runBridge(): Promise<void> {
  log.banner("Circle CCTP V2 · Base Mainnet → Arc Mainnet");

  // -------------------------------------------------------------------------
  // 1. Validate config
  // -------------------------------------------------------------------------
  log.step("Validating configuration");
  const pk = validatePrivateKey(PRIVATE_KEY);
  const baseRpc = validateRpc(BASE_RPC, "BASE_RPC");
  const arcRpc = validateRpc(ARC_RPC, "ARC_RPC");
  const irisApi = validateRpc(IRIS_API, "IRIS_API");

  const amount = parseUsdc(AMOUNT_USDC);
  if (amount <= 0n) throw new Error(`AMOUNT_USDC must be > 0. Got "${AMOUNT_USDC}".`);

  const mode = TRANSFER_MODE;
  if (mode !== "fast" && mode !== "standard") {
    throw new Error(`TRANSFER_MODE must be "fast" or "standard". Got "${mode}".`);
  }
  const finalityThreshold =
    mode === "fast" ? FINALITY_THRESHOLD_FAST : FINALITY_THRESHOLD_STANDARD;
  const maxFee = mode === "fast" ? parseUsdc(MAX_FEE_USDC) : 0n;
  if (mode === "fast" && maxFee >= amount) {
    throw new Error(
      `MAX_FEE_USDC (${MAX_FEE_USDC}) must be < AMOUNT_USDC (${AMOUNT_USDC}).`
    );
  }

  const account = privateKeyToAccount(pk);
  const recipient: Address =
    RECIPIENT_OVERRIDE && RECIPIENT_OVERRIDE.trim().length > 0
      ? validateAddress(RECIPIENT_OVERRIDE.trim(), "RECIPIENT_OVERRIDE")
      : account.address;

  log.key("Wallet Address :", account.address);
  log.key("Recipient (Arc):", recipient);
  log.key("Amount         :", `${AMOUNT_USDC} USDC (${amount.toString()} base units)`);
  log.key("Mode           :", `${mode} (minFinalityThreshold=${finalityThreshold})`);
  if (mode === "fast") log.key("Max Fee        :", `${MAX_FEE_USDC} USDC`);
  log.key("Iris API       :", irisApi);

  // -------------------------------------------------------------------------
  // 2. Connect Base + Arc
  // -------------------------------------------------------------------------
  log.step("Connecting to Base");
  const basePublic = createPublicClient({ transport: http(baseRpc) });
  const baseWallet = createWalletClient({ account, transport: http(baseRpc) });
  const baseChainId = await basePublic.getChainId();
  log.key("Base chainId  :", baseChainId.toString());

  log.step("Connecting to Arc");
  const arcPublic = createPublicClient({ transport: http(arcRpc) });
  const arcWallet = createWalletClient({ account, transport: http(arcRpc) });
  const arcChainId = await arcPublic.getChainId();
  log.key("Arc chainId   :", arcChainId.toString());

  // -------------------------------------------------------------------------
  // 3. Check balances
  // -------------------------------------------------------------------------
  log.step("Checking balances");
  const [usdcBal, baseGas, arcGas] = await Promise.all([
    basePublic.readContract({
      address: USDC_BASE,
      abi: ERC20_ABI,
      functionName: "balanceOf",
      args: [account.address],
    }) as Promise<bigint>,
    basePublic.getBalance({ address: account.address }),
    arcPublic.getBalance({ address: account.address }),
  ]);

  log.key("USDC Balance  :", `${formatUsdc(usdcBal)} USDC`);
  log.key("Base gas      :", `${baseGas.toString()} wei`);
  log.key("Arc gas       :", `${arcGas.toString()} wei`);

  if (usdcBal < amount) {
    throw new Error(
      `Insufficient USDC on Base. Have ${formatUsdc(usdcBal)}, need ${AMOUNT_USDC}.`
    );
  }
  if (baseGas === 0n) {
    throw new Error(
      "Wallet has 0 native ETH on Base. Cannot pay gas for approve() + depositForBurn()."
    );
  }
  if (arcGas === 0n) {
    log.warn(
      "Wallet has 0 native gas on Arc. receiveMessage() will fail unless gas is funded before mint."
    );
  }

  // -------------------------------------------------------------------------
  // 4. Approve USDC if needed
  // -------------------------------------------------------------------------
  await ensureApproval({
    publicClient: basePublic,
    walletClient: baseWallet,
    account,
    amount,
  });

  // -------------------------------------------------------------------------
  // 5. depositForBurn on Base
  // -------------------------------------------------------------------------
  log.step("Calling depositForBurn() on Base");
  const mintRecipient = addressToBytes32(recipient);

  log.key("destinationDomain    :", DOMAIN_ARC.toString());
  log.key("mintRecipient (b32)  :", mintRecipient);
  log.key("burnToken            :", USDC_BASE);
  log.key("destinationCaller    :", ZERO_BYTES32);
  log.key("maxFee               :", `${maxFee.toString()} (base units)`);
  log.key("minFinalityThreshold :", finalityThreshold.toString());

  const burnHash = await baseWallet.writeContract({
    account,
    chain: null,
    address: TOKEN_MESSENGER_V2,
    abi: TOKEN_MESSENGER_V2_ABI,
    functionName: "depositForBurn",
    args: [
      amount,
      DOMAIN_ARC,
      mintRecipient,
      USDC_BASE,
      ZERO_BYTES32,
      maxFee,
      finalityThreshold,
    ],
  });

  log.ok(`Base burn tx submitted`);
  log.key("Base tx hash  :", burnHash);

  log.wait("Waiting for Base confirmation…");
  const burnReceipt = await basePublic.waitForTransactionReceipt({ hash: burnHash });
  if (burnReceipt.status !== "success") {
    throw new Error(`depositForBurn() reverted on Base. tx: ${burnHash}`);
  }
  log.ok(`Base burn confirmed in block ${burnReceipt.blockNumber}`);

  // -------------------------------------------------------------------------
  // 6. Poll Iris for attestation
  // -------------------------------------------------------------------------
  // Small delay to give Iris a chance to observe the tx before first poll.
  await sleep(2000);
  const attestation = await waitForAttestation({
    sourceDomain: DOMAIN_BASE,
    burnTxHash: burnHash,
  });

  // -------------------------------------------------------------------------
  // 7. receiveMessage on Arc
  // -------------------------------------------------------------------------
  const arcHash = await receiveOnArc({
    publicClient: arcPublic,
    walletClient: arcWallet,
    account,
    attestation,
  });

  // -------------------------------------------------------------------------
  // Report
  // -------------------------------------------------------------------------
  log.key("Base burn tx  :", burnHash);
  log.key("Arc mint tx   :", arcHash);
  log.key("Recipient     :", recipient);
  log.key("Amount        :", `${AMOUNT_USDC} USDC`);

  // Optionally read post-mint balance if USDC_ARC is set
  if (USDC_ARC !== "0x0000000000000000000000000000000000000000") {
    try {
      const arcUsdc = (await arcPublic.readContract({
        address: USDC_ARC,
        abi: ERC20_ABI,
        functionName: "balanceOf",
        args: [recipient],
      })) as bigint;
      log.key("Arc USDC bal  :", `${formatUsdc(arcUsdc)} USDC`);
    } catch {
      /* silent — USDC_ARC may not be deployed yet */
    }
  }

  log.done("Bridge Completed");
}
