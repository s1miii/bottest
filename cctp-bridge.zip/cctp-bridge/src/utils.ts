// ============================================================================
//  utils.ts
// ----------------------------------------------------------------------------
//  Small helpers: address encoding, USDC parsing/formatting, validation, sleep.
// ============================================================================

import {
  type Address,
  type Hex,
  formatUnits,
  isAddress,
  isHex,
  pad,
  parseUnits,
} from "viem";
import { USDC_DECIMALS } from "./constants.js";

/** Pad an EVM address to a bytes32 value (left-zero-padded). */
export function addressToBytes32(addr: Address): Hex {
  return pad(addr.toLowerCase() as Hex, { size: 32 });
}

/** Parse a USDC decimal string ("10", "0.5") to a base-unit bigint. */
export function parseUsdc(amount: string): bigint {
  return parseUnits(amount, USDC_DECIMALS);
}

/** Format a base-unit bigint to a human USDC string. */
export function formatUsdc(amount: bigint): string {
  return formatUnits(amount, USDC_DECIMALS);
}

/** Sleep for `ms` milliseconds. */
export const sleep = (ms: number) =>
  new Promise<void>((resolve) => setTimeout(resolve, ms));

/** Validate that the given string is a 0x-prefixed 32-byte private key. */
export function validatePrivateKey(pk: string): Hex {
  if (typeof pk !== "string") {
    throw new Error("PRIVATE_KEY must be a string.");
  }
  const key = pk.trim();
  if (!/^0x[0-9a-fA-F]{64}$/.test(key)) {
    throw new Error(
      "PRIVATE_KEY is invalid: must be 0x-prefixed 64 hex characters (32 bytes). Update src/config.ts."
    );
  }
  return key as Hex;
}

/** Validate an RPC URL string. */
export function validateRpc(url: string, label: string): string {
  if (typeof url !== "string" || url.trim().length === 0) {
    throw new Error(`${label} is empty. Update src/config.ts.`);
  }
  const trimmed = url.trim();
  if (!/^https?:\/\//.test(trimmed)) {
    throw new Error(
      `${label} must be a valid http(s) URL. Got: "${trimmed}". Update src/config.ts.`
    );
  }
  if (trimmed.toUpperCase().includes("REPLACE_WITH")) {
    throw new Error(
      `${label} still contains a placeholder ("${trimmed}"). Update src/config.ts.`
    );
  }
  return trimmed;
}

/** Validate an EVM address. */
export function validateAddress(addr: string, label: string): Address {
  if (!isAddress(addr)) {
    throw new Error(`${label} is not a valid EVM address: ${addr}`);
  }
  return addr as Address;
}

/** Validate arbitrary hex string. */
export function validateHex(v: string, label: string): Hex {
  if (!isHex(v)) {
    throw new Error(`${label} is not valid hex: ${v}`);
  }
  return v as Hex;
}
