// ============================================================================
//  config.ts
// ----------------------------------------------------------------------------
//  All configuration lives here. No .env, no dotenv, no environment variables.
//  Edit these values directly.
//
//  SECURITY WARNING: this file contains your PRIVATE_KEY in plaintext.
//  Do NOT commit, push, or share this file. Keep it local.
// ============================================================================

/**
 * The private key of the wallet that will:
 *   - Approve USDC on Base
 *   - Burn USDC on Base (depositForBurn)
 *   - Mint USDC on Arc  (receiveMessage)
 *
 * Must start with "0x" and be 64 hex chars.
 */
export const PRIVATE_KEY =
  "0xREPLACE_WITH_YOUR_PRIVATE_KEY_64_HEX_CHARS_0000000000000000000000";

/**
 * Base Mainnet JSON-RPC endpoint.
 * Public: https://mainnet.base.org
 * (Alchemy / Infura / QuickNode recommended for reliability.)
 */
export const BASE_RPC = "https://mainnet.base.org";

/**
 * Arc Mainnet JSON-RPC endpoint.
 *
 * NOTE (Feb 2026): Arc mainnet may not yet be live. If it is not, paste the
 * mainnet RPC URL here as soon as Circle publishes it. For Arc testnet use:
 *   https://rpc.arc-testnet.circle.com
 */
export const ARC_RPC = "https://REPLACE_WITH_ARC_MAINNET_RPC";

/**
 * Circle Iris API base URL (no trailing slash).
 *   Mainnet: https://iris-api.circle.com
 *   Testnet: https://iris-api-sandbox.circle.com
 */
export const IRIS_API = "https://iris-api.circle.com";

/**
 * Amount of USDC to bridge, expressed as a decimal string in whole USDC
 * (6 decimals will be applied automatically).
 * Example: "10"    -> 10 USDC
 *          "0.5"   -> 0.5 USDC
 *          "1234"  -> 1,234 USDC
 */
export const AMOUNT_USDC = "10";

/**
 * CCTP V2 transfer mode.
 *   "fast"     -> minFinalityThreshold = 1000  (seconds, small fee)
 *   "standard" -> minFinalityThreshold = 2000  (~13-19 min, no fee)
 */
export const TRANSFER_MODE: "fast" | "standard" = "fast";

/**
 * Maximum fee (in USDC, decimal string) you are willing to pay for a
 * Fast Transfer. Ignored for "standard".
 * Circle's quoted fee is usually <= 0.01 USDC. 0.5 gives generous headroom.
 */
export const MAX_FEE_USDC = "0.5";

/**
 * Recipient of the minted USDC on Arc. Leave empty string to send to the
 * same wallet as PRIVATE_KEY (default and typical behaviour).
 */
export const RECIPIENT_OVERRIDE: string = "";

/**
 * Poll interval (ms) for the Circle Iris attestation service.
 * Spec requires 5000ms.
 */
export const POLL_INTERVAL_MS = 5000;

/**
 * Maximum total time to wait for an attestation before aborting (ms).
 * 20 minutes is enough for Standard transfers on Base.
 */
export const ATTESTATION_TIMEOUT_MS = 20 * 60 * 1000;
