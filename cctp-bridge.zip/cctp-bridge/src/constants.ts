// ============================================================================
//  constants.ts
// ----------------------------------------------------------------------------
//  Official Circle CCTP V2 contract addresses & chain constants.
//  Sources (verified Feb 2026):
//    - https://developers.circle.com/cctp/references/contract-addresses
//    - https://developers.circle.com/cctp/references/contract-interfaces
//    - https://developers.circle.com/cctp/concepts/supported-chains-and-domains
// ============================================================================

import type { Address } from "viem";

// ---------------------------------------------------------------------------
// Circle CCTP domain identifiers
// ---------------------------------------------------------------------------
export const DOMAIN_BASE = 6;
export const DOMAIN_ARC = 26;

// ---------------------------------------------------------------------------
// Chain IDs
// ---------------------------------------------------------------------------
export const CHAIN_ID_BASE = 8453;
// NOTE: Arc mainnet chain ID may change. Update when Circle publishes it.
export const CHAIN_ID_ARC = 421;

// ---------------------------------------------------------------------------
// USDC token addresses (native)
// ---------------------------------------------------------------------------
// Base Mainnet native USDC (Circle-issued)
export const USDC_BASE: Address = "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913";
// Arc Mainnet native USDC — VERIFY & REPLACE when Arc mainnet goes live.
export const USDC_ARC: Address = "0x0000000000000000000000000000000000000000";

// ---------------------------------------------------------------------------
// CCTP V2 contracts — same address across every EVM mainnet Circle supports
// ---------------------------------------------------------------------------
export const TOKEN_MESSENGER_V2: Address =
  "0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d";
export const MESSAGE_TRANSMITTER_V2: Address =
  "0x81D40F21F12A8F0E3252Bccb954D722d4c464B64";
export const TOKEN_MINTER_V2: Address =
  "0xfd78EE919681417d192449715b2594ab58f5D002";
export const MESSAGE_V2: Address =
  "0xec546b6B005471ECf012e5aF77FBeC07e0FD8f78";

// ---------------------------------------------------------------------------
// CCTP V2 finality thresholds
// ---------------------------------------------------------------------------
export const FINALITY_THRESHOLD_FAST = 1000;
export const FINALITY_THRESHOLD_STANDARD = 2000;

// ---------------------------------------------------------------------------
// USDC decimals
// ---------------------------------------------------------------------------
export const USDC_DECIMALS = 6;

// ---------------------------------------------------------------------------
// Minimal ABIs
// ---------------------------------------------------------------------------
export const ERC20_ABI = [
  {
    type: "function",
    name: "balanceOf",
    stateMutability: "view",
    inputs: [{ name: "account", type: "address" }],
    outputs: [{ type: "uint256" }],
  },
  {
    type: "function",
    name: "allowance",
    stateMutability: "view",
    inputs: [
      { name: "owner", type: "address" },
      { name: "spender", type: "address" },
    ],
    outputs: [{ type: "uint256" }],
  },
  {
    type: "function",
    name: "approve",
    stateMutability: "nonpayable",
    inputs: [
      { name: "spender", type: "address" },
      { name: "amount", type: "uint256" },
    ],
    outputs: [{ type: "bool" }],
  },
  {
    type: "function",
    name: "decimals",
    stateMutability: "view",
    inputs: [],
    outputs: [{ type: "uint8" }],
  },
  {
    type: "function",
    name: "symbol",
    stateMutability: "view",
    inputs: [],
    outputs: [{ type: "string" }],
  },
] as const;

// CCTP V2 TokenMessengerV2.depositForBurn signature
export const TOKEN_MESSENGER_V2_ABI = [
  {
    type: "function",
    name: "depositForBurn",
    stateMutability: "nonpayable",
    inputs: [
      { name: "amount", type: "uint256" },
      { name: "destinationDomain", type: "uint32" },
      { name: "mintRecipient", type: "bytes32" },
      { name: "burnToken", type: "address" },
      { name: "destinationCaller", type: "bytes32" },
      { name: "maxFee", type: "uint256" },
      { name: "minFinalityThreshold", type: "uint32" },
    ],
    outputs: [],
  },
] as const;

// CCTP V2 MessageTransmitterV2.receiveMessage signature
export const MESSAGE_TRANSMITTER_V2_ABI = [
  {
    type: "function",
    name: "receiveMessage",
    stateMutability: "nonpayable",
    inputs: [
      { name: "message", type: "bytes" },
      { name: "attestation", type: "bytes" },
    ],
    outputs: [{ type: "bool" }],
  },
] as const;
