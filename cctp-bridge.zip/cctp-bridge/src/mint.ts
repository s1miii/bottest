// ============================================================================
//  mint.ts
// ----------------------------------------------------------------------------
//  Call MessageTransmitterV2.receiveMessage(message, attestation) on Arc
//  to mint the native USDC on the destination chain.
// ============================================================================

import type { Account, PublicClient, WalletClient } from "viem";
import type { Attestation } from "./iris.js";
import {
  MESSAGE_TRANSMITTER_V2,
  MESSAGE_TRANSMITTER_V2_ABI,
} from "./constants.js";
import { log } from "./logger.js";

export async function receiveOnArc(params: {
  publicClient: PublicClient;
  walletClient: WalletClient;
  account: Account;
  attestation: Attestation;
}): Promise<`0x${string}`> {
  const { publicClient, walletClient, account, attestation } = params;

  log.step("Submitting receiveMessage() on Arc");

  const hash = await walletClient.writeContract({
    account,
    chain: null,
    address: MESSAGE_TRANSMITTER_V2,
    abi: MESSAGE_TRANSMITTER_V2_ABI,
    functionName: "receiveMessage",
    args: [attestation.message, attestation.attestation],
  });

  log.key("Arc mint tx hash:", hash);

  log.wait("Waiting for Arc confirmation…");
  const receipt = await publicClient.waitForTransactionReceipt({ hash });
  if (receipt.status !== "success") {
    throw new Error(`receiveMessage() reverted on Arc. tx: ${hash}`);
  }
  log.ok(`Mint confirmed on Arc in block ${receipt.blockNumber}`);
  return hash;
}
