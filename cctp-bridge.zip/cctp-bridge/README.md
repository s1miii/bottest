# CCTP V2 · Base → Arc CLI Bridge

Personal CLI for bridging **native USDC** from **Base Mainnet** to **Arc Mainnet**
using Circle's official **CCTP V2** contracts.

> Private use only. Not for publication. No `.env`, no dotenv, no config files.

---

## Stack
- Node.js + TypeScript (ESM)
- viem (RPC + wallet)
- chalk (colorful logs)
- Circle Iris V2 attestation API

---

## Install

```bash
cd cctp-bridge
yarn install         # or: npm install
```

---

## Configure

Open `src/config.ts` and edit the values directly:

| Constant             | Meaning                                              |
| -------------------- | ---------------------------------------------------- |
| `PRIVATE_KEY`        | Wallet key (0x + 64 hex). Signs on **both** chains. |
| `BASE_RPC`           | Base Mainnet RPC (e.g. `https://mainnet.base.org`). |
| `ARC_RPC`            | Arc Mainnet RPC.                                    |
| `IRIS_API`           | `https://iris-api.circle.com` (mainnet).            |
| `AMOUNT_USDC`        | Amount to bridge as a decimal string (e.g. `"10"`). |
| `TRANSFER_MODE`      | `"fast"` (~seconds, small fee) or `"standard"` (~13-19 min, no fee). |
| `MAX_FEE_USDC`       | Ceiling for Fast Transfer fee (ignored for standard). |
| `RECIPIENT_OVERRIDE` | Optional. Empty = same wallet on Arc.               |

> **Never** commit this file. Keep it local.

---

## Run

```bash
yarn start
# or
npx tsx src/index.ts
```

---

## Flow

1. Validate `config.ts`
2. Connect Base + Arc
3. Check USDC balance + gas balances on both chains
4. `approve()` USDC to `TokenMessengerV2` on Base (if needed)
5. `depositForBurn()` on Base → prints **Base tx hash**
6. Poll `IRIS_API/v2/messages/6?transactionHash=...` every 5 s until `status == "complete"`
7. `receiveMessage()` on Arc → prints **Arc tx hash**
8. Prints **Bridge Completed**

---

## Verified contract addresses (from Circle docs, Feb 2026)

| Item                   | Address                                                                 |
| ---------------------- | ----------------------------------------------------------------------- |
| USDC on Base           | `0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913`                              |
| TokenMessengerV2       | `0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d` (same on every EVM mainnet) |
| MessageTransmitterV2   | `0x81D40F21F12A8F0E3252Bccb954D722d4c464B64` (same on every EVM mainnet) |
| Base domain            | `6`                                                                     |
| Arc domain             | `26`                                                                    |

Sources:
- https://developers.circle.com/cctp/references/contract-addresses
- https://developers.circle.com/cctp/references/contract-interfaces

---

## Arc mainnet caveat

Arc is Circle's own L1. As of **February 2026** it is publicly documented at
domain `26` but has been running as **testnet** on `https://rpc.arc-testnet.circle.com`.
When Arc mainnet launches:

- Paste the mainnet RPC into `ARC_RPC` in `src/config.ts`.
- Update `USDC_ARC` in `src/constants.ts` with the mainnet USDC address.
- `TokenMessengerV2` and `MessageTransmitterV2` are already at the standard
  addresses Circle uses across every V2 mainnet, so those constants should not
  need to change (verify against Circle docs on launch day).

---

## Project structure

```
cctp-bridge/
├── package.json
├── tsconfig.json
├── README.md
└── src/
    ├── config.ts        # editable configuration (private key, RPCs, amount)
    ├── constants.ts     # CCTP V2 addresses, ABIs, domain IDs, decimals
    ├── logger.ts        # colorful logs (chalk)
    ├── utils.ts         # validation + address/amount helpers
    ├── approve.ts       # USDC approve() on Base
    ├── iris.ts          # Circle Iris V2 attestation poller
    ├── mint.ts          # receiveMessage() on Arc
    ├── bridge.ts        # end-to-end orchestrator
    └── index.ts         # CLI entry point
```

---

## Errors handled

- Invalid private key format
- Empty / placeholder RPC URLs
- Iris fetch errors (retried every 5 s)
- Iris 404 (message not yet indexed)
- Insufficient USDC balance
- Zero native gas on Base
- Zero native gas on Arc (warning; will fail at mint if not funded)
- `approve()` / `depositForBurn()` / `receiveMessage()` reverts
- Iris timeout (default 20 minutes, configurable in `config.ts`)
- Config drift (Fast Transfer with `maxFee >= amount`)
